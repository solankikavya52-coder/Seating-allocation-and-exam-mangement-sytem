/*
 * Student 5 OS module: synchronized attendance updates using a POSIX mutex.
 * Build: gcc -std=c11 -Wall -Wextra -pthread attendance_mutex_demo.c -o attendance_mutex_demo
 * Run:   ./attendance_mutex_demo
 * This models two concurrent requests trying to update one attendance record.
 */
#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static pthread_mutex_t attendance_lock = PTHREAD_MUTEX_INITIALIZER;
static int attendance_version = 0;
static const char *current_status = "NOT_MARKED";

typedef struct { const char *requested_status; const char *invigilator_name; } UpdateRequest;

static void short_pause(void) {
    struct timespec delay = { .tv_sec = 0, .tv_nsec = 40000000L };
    nanosleep(&delay, NULL);
}

static void *update_attendance(void *argument) {
    UpdateRequest *request = (UpdateRequest *)argument;
    int rc = pthread_mutex_lock(&attendance_lock);
    if (rc != 0) {
        fprintf(stderr, "Could not lock attendance record (error %d).\n", rc);
        return NULL;
    }
    /* Critical section: read current state, apply update, and increment version together. */
    printf("%s opened the attendance record. Current status: %s\n",
           request->invigilator_name, current_status);
    short_pause();
    current_status = request->requested_status;
    attendance_version++;
    printf("%s saved status %s (record version %d).\n",
           request->invigilator_name, current_status, attendance_version);
    pthread_mutex_unlock(&attendance_lock);
    return NULL;
}

int main(void) {
    pthread_t first, second;
    UpdateRequest request_a = { "PRESENT", "Invigilator A" };
    UpdateRequest request_b = { "LATE", "Invigilator B" };
    puts("Two simultaneous attendance updates are being simulated.");
    puts("A mutex ensures only one thread changes the shared record at a time.\n");
    int rc = pthread_create(&first, NULL, update_attendance, &request_a);
    if (rc != 0) {
        fprintf(stderr, "pthread_create failed (error %d).\n", rc);
        return EXIT_FAILURE;
    }
    rc = pthread_create(&second, NULL, update_attendance, &request_b);
    if (rc != 0) {
        fprintf(stderr, "pthread_create failed (error %d).\n", rc);
        pthread_join(first, NULL);
        return EXIT_FAILURE;
    }
    pthread_join(first, NULL);
    pthread_join(second, NULL);
    printf("\nFinal record: status=%s, version=%d\n", current_status, attendance_version);
    puts("In the web application, MySQL transactions and unique keys protect persisted attendance too.");
    pthread_mutex_destroy(&attendance_lock);
    return 0;
}
