const mysql = require('mysql2/promise');
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'exam_app',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'exam_operations',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  namedPlaceholders: true,
  timezone: 'Z'
});
module.exports = pool;
