const express = require('express');
const pool = require('./db');
const attendanceRoutes = require('./routes/attendanceRoutes');
const app = express();
app.use(express.json());
// Replace this placeholder with the real authentication + role middleware from the team project.
app.use('/api/attendance', attendanceRoutes(pool));
app.use((err, _req, res, _next) => {
  console.error(err);
  const clientError = /must be|Invalid|already exists|not found|submitted|reason|authorized/.test(err.message || '');
  res.status(clientError ? 400 : 500).json({ success: false, message: clientError ? err.message : 'The attendance request could not be completed.' });
});
app.listen(process.env.PORT || 3002, () => console.log('Attendance API ready'));
