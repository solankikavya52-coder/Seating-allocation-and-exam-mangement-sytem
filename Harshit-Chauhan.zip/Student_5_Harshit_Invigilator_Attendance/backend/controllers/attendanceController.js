function createAttendanceController(service) {
  return {
    myDuties: async (req, res, next) => {
      try {
        // In the real application, invigilatorId must come from the authenticated session, not the URL.
        const invigilatorId = req.user?.invigilatorId;
        if (!invigilatorId) return res.status(403).json({ success: false, message: 'Invigilator access is required' });
        res.json({ success: true, data: await service.listDutyForInvigilator(invigilatorId) });
      } catch (error) { next(error); }
    },
    sessions: async (req, res, next) => {
      try { res.json({ success: true, data: await service.listSessions(req.query) }); }
      catch (error) { next(error); }
    },
    mark: async (req, res, next) => {
      try {
        const data = await service.markAttendance({ ...req.body, markedBy: req.user?.invigilatorId });
        res.status(201).json({ success: true, message: 'Attendance recorded', data });
      } catch (error) { next(error); }
    },
    correct: async (req, res, next) => {
      try {
        if (req.user?.role !== 'ADMIN' && req.user?.role !== 'EXAM_CONTROLLER') {
          return res.status(403).json({ success: false, message: 'Only an authorized examination administrator can correct attendance' });
        }
        const data = await service.correctAttendance({ ...req.body, attendanceId: req.params.attendanceId, changedBy: req.user?.invigilatorId });
        res.json({ success: true, message: 'Attendance correction recorded', data });
      } catch (error) { next(error); }
    }
  };
}
module.exports = { createAttendanceController };
