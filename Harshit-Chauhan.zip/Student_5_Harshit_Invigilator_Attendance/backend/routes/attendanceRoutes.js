const express = require('express');
const { createAttendanceService } = require('../services/attendanceService');
const { createAttendanceController } = require('../controllers/attendanceController');
function attendanceRoutes(pool, requireInvigilatorOrAdmin = (_req, _res, next) => next()) {
  const router = express.Router();
  const controller = createAttendanceController(createAttendanceService(pool));
  router.use(requireInvigilatorOrAdmin);
  router.get('/my-duties', controller.myDuties);
  router.get('/sessions', controller.sessions);
  router.post('/mark', controller.mark);
  router.patch('/:attendanceId/correct', controller.correct);
  return router;
}
module.exports = attendanceRoutes;
