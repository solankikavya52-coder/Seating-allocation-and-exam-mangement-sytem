USE exam_system;
-- 1. Invigilator duty schedule.
SELECT * FROM VW_INVIGILATOR_DUTY_SCHEDULE ORDER BY exam_id,room_no,duty_role;

-- 2. Room-wise attendance summary.
SELECT * FROM VW_EXAM_ATTENDANCE_SUMMARY ORDER BY exam_id,room_no;

-- 3. All attendance records for one session (replace session_id 1).
SELECT a.attendance_id,s.roll_no,s.name,a.attendance_status,a.marked_at,a.remarks,i.full_name AS marked_by
FROM ATTENDANCE a JOIN STUDENT s ON s.student_id=a.student_id
JOIN INVIGILATOR i ON i.invigilator_id=a.marked_by WHERE a.session_id=1 ORDER BY s.roll_no;

-- 4. Students whose attendance has not yet been marked for a session.
-- Replace exam_id and session_id. Assumes Student 2's EXAM_REGISTRATION(exam_id,student_id) table.
SELECT s.student_id,s.roll_no,s.name FROM STUDENT s
JOIN EXAM_REGISTRATION er ON er.student_id=s.student_id AND er.exam_id=1
WHERE NOT EXISTS (SELECT 1 FROM ATTENDANCE a WHERE a.session_id=1 AND a.student_id=s.student_id)
ORDER BY s.roll_no;

-- 5. Attendance correction history.
SELECT l.change_id,a.session_id,a.student_id,l.old_status,l.new_status,l.change_reason,
 i.full_name AS changed_by,l.changed_at
FROM ATTENDANCE_CHANGE_LOG l JOIN ATTENDANCE a ON a.attendance_id=l.attendance_id
JOIN INVIGILATOR i ON i.invigilator_id=l.changed_by ORDER BY l.changed_at DESC LIMIT 100;

-- 6. Possible duty clash: an invigilator assigned to more than one room for the same exam.
SELECT exam_id,invigilator_id,COUNT(DISTINCT room_id) AS rooms_assigned
FROM EXAM_INVIGILATOR WHERE duty_status IN ('ASSIGNED','CONFIRMED')
GROUP BY exam_id,invigilator_id HAVING COUNT(DISTINCT room_id)>1;

-- 7. Present percentage per room session.
SELECT session_id,exam_id,room_no,marked_students,present_count,absent_count,late_count,excused_count,
 ROUND(100.0*present_count/NULLIF(marked_students,0),2) AS present_percentage
FROM VW_EXAM_ATTENDANCE_SUMMARY;
