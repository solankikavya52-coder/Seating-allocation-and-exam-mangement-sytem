USE exam_system;
DELIMITER $$
CREATE PROCEDURE sp_mark_exam_attendance(
 IN p_session_id BIGINT UNSIGNED, IN p_student_id INT,
 IN p_status VARCHAR(20), IN p_marked_by INT, IN p_remarks VARCHAR(300))
BEGIN
 DECLARE v_session_status VARCHAR(20);
 DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
 IF p_status NOT IN ('PRESENT','ABSENT','LATE','EXCUSED') THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Invalid attendance status'; END IF;
 START TRANSACTION;
 SELECT session_status INTO v_session_status FROM ATTENDANCE_SESSION WHERE session_id=p_session_id FOR UPDATE;
 IF v_session_status IS NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Attendance session was not found'; END IF;
 IF v_session_status='SUBMITTED' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Submitted attendance is locked'; END IF;
 IF EXISTS(SELECT 1 FROM ATTENDANCE WHERE session_id=p_session_id AND student_id=p_student_id) THEN
   SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Attendance already exists; use the correction workflow';
 END IF;
 INSERT INTO ATTENDANCE(session_id,student_id,attendance_status,marked_by,remarks)
 VALUES(p_session_id,p_student_id,p_status,p_marked_by,p_remarks);
 COMMIT;
END$$

CREATE PROCEDURE sp_correct_exam_attendance(
 IN p_attendance_id BIGINT UNSIGNED, IN p_new_status VARCHAR(20),
 IN p_changed_by INT, IN p_reason VARCHAR(300))
BEGIN
 DECLARE v_old_status VARCHAR(20); DECLARE v_session_status VARCHAR(20);
 DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
 IF p_new_status NOT IN ('PRESENT','ABSENT','LATE','EXCUSED') THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Invalid attendance status'; END IF;
 IF p_reason IS NULL OR CHAR_LENGTH(TRIM(p_reason))<5 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='A correction reason of at least 5 characters is required'; END IF;
 START TRANSACTION;
 SELECT a.attendance_status,s.session_status INTO v_old_status,v_session_status
 FROM ATTENDANCE a JOIN ATTENDANCE_SESSION s ON s.session_id=a.session_id
 WHERE a.attendance_id=p_attendance_id FOR UPDATE;
 IF v_old_status IS NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Attendance record was not found'; END IF;
 IF v_session_status='SUBMITTED' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Ask an administrator to reopen the session first'; END IF;
 UPDATE ATTENDANCE SET attendance_status=p_new_status,marked_by=p_changed_by,marked_at=CURRENT_TIMESTAMP WHERE attendance_id=p_attendance_id;
 INSERT INTO ATTENDANCE_CHANGE_LOG(attendance_id,old_status,new_status,changed_by,change_reason)
 VALUES(p_attendance_id,v_old_status,p_new_status,p_changed_by,TRIM(p_reason));
 COMMIT;
END$$
DELIMITER ;
